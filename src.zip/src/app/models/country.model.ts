export interface Country {
  name: {
    common: string
    official: string
  }
  cca2: string
  cca3: string
  flag: string
}
